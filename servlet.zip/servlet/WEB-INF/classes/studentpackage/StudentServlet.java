package  studentpackage;
import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.util.*;
import java.sql.*;
import org.json.JSONObject;
import org.json.simple.JSONValue;  

public class StudentServlet extends HttpServlet{
    JdbcData dataobj = new JdbcData();
    public void doPost(HttpServletRequest request, HttpServletResponse response){
        ArrayList<Student> std = new ArrayList<Student>();
        ArrayList<Student> fullStd = new ArrayList<Student>();
        try{
            JSONObject json = new JSONObject();
            fullStd = dataobj.getData();
            response.setContentType("text/html");
            PrintWriter out = response.getWriter();   
            int userrollNo= Integer.parseInt(request.getParameter("rollNo"));
            ServletContext context = getServletContext();
            String StringLoginUserName = (String)context.getAttribute("username");
            int LoginUserName = Integer.parseInt(StringLoginUserName);  
            String jsonText="";
            if (LoginUserName == userrollNo){
                for(int i=0;i<fullStd.size();i++){
                    Student s = fullStd.get(i);
                    if (s.rollNo == userrollNo){
                        Map obj=new HashMap();                       
                        obj.put("name",s.name);
                        obj.put("rollNo",s.rollNo);
                        obj.put("department",s.department);
                        obj.put("dob",s.dob);                        
                        obj.put("college",s.college);
                        obj.put("m1",s.m1);
                        obj.put("m2",s.m2);
                        obj.put("m3",s.m3);
                        obj.put("m4",s.m4);
                        obj.put("m5",s.m5);
                        obj.put("total",s.total);                
                        jsonText = JSONValue.toJSONString(obj);  
                        response.getWriter().write(jsonText.toString());
                        break;
                    }
                }
            }
            else{
                String validationMessage ="! ! ! Enter Your Roll No ! ! !";
                response.getWriter().write(validationMessage);
            }            
        }catch (Exception e)
        {   
            e.printStackTrace(); 
        }
    }
}