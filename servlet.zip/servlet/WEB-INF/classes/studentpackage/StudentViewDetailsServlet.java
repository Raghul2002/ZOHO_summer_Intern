package  studentpackage;
import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.util.*;
import java.sql.*;
import org.json.*;  

public class StudentViewDetailsServlet extends HttpServlet{
    JdbcConnection jdbcobj = new JdbcConnection();
    public void doGet(HttpServletRequest request,HttpServletResponse response){
        try{            
            String result = request.getParameter("result");
            request.setAttribute("result",result);
            String nextJSP = "/studentviewdetails.jsp";
            RequestDispatcher dispatcher = getServletContext().getRequestDispatcher(nextJSP);
            dispatcher.forward(request,response);
            String validationMessage ="1";
            response.getWriter().write(validationMessage);
        }catch(Exception e)
        {
            e.printStackTrace();
        }
    }
}