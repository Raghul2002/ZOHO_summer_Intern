package  studentpackage;
import java.sql.*;

public class JdbcConnection {  
    // JDBC driver name and database URL
    
    static final String JDBC_DRIVER = "org.postgresql.Driver";
    static final String DB_URL = "jdbc:postgresql://localhost/studentdb";
    // Database credentials
    static final String USER = "postgres" ;
    static final String PASS = "123";
    public Connection getConnection() 
    {
        Connection conn = null;
        Statement stmt = null;
        try{
             Class.forName("org.postgresql.Driver");
            String sql;
            conn = DriverManager.getConnection(DB_URL,USER,PASS);
        }
        catch(SQLException e){
            System.out.println(e); 

        }catch (Exception e) {
         e.printStackTrace();
         System.err.println(e.getClass().getName()+": "+e.getMessage());
        }

    return(conn);   
    }

}