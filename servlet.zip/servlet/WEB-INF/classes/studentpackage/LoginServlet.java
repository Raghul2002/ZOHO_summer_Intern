package  studentpackage;
import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.util.*;
import java.sql.*;

public class LoginServlet extends HttpServlet{
    JdbcConnection jdbcobj = new JdbcConnection();
    public void doGet(HttpServletRequest request,HttpServletResponse response){
        try{
            RequestDispatcher l= request.getRequestDispatcher("/login.jsp");
            l.forward(request, response);
        }catch(Exception e)
        {
            e.printStackTrace();
        }
    }
    public void doPost(HttpServletRequest request, HttpServletResponse response){
        try{
            int flag = 0;
            String dbdob="";
            int dbrollNo;
            Connection conn = null;
            String sql;
            response.setContentType("text/html");
            PrintWriter out = response.getWriter();
            String StringrollNo=request.getParameter("rollNo");
            String dob= request.getParameter("dob");            
            ServletContext servletcontext = getServletContext();           // RollNo stored as string
            servletcontext.setAttribute("username",StringrollNo);
            int rollNo=Integer.parseInt(StringrollNo);
            conn = jdbcobj.getConnection();
            PreparedStatement stmt=conn.prepareStatement("select * from table_servlet");  
            ResultSet rs=stmt.executeQuery(); 
            while ( rs.next() ) {						 			//Retreve data from db
                dbrollNo = Integer.parseInt(rs.getString(2));
                dbdob = rs.getString(4);  
				dbdob = dbdob.trim(); 
				if( dbrollNo == rollNo)
				{
					if (dbdob.equals(dob)){
						flag = 1;
						break;
					}
				}
			}
        	rs.close();
            stmt.close();
            conn.close();
            if (flag ==1 ){
                String role = request.getParameter("role");
                if (role.equals("admin"))
                {
                    String validationMessage ="Admin";
                    response.getWriter().write(validationMessage);
                }
                else{
                    String validationMessage ="Student";
                    response.getWriter().write(validationMessage);
                }
            }
            else{
                String validationMessage ="! ! !Wrong Username and Password ! ! !";
                response.getWriter().write(validationMessage);
            }
        }catch (Exception e)
        {   
            e.printStackTrace();   
        }
    }
}