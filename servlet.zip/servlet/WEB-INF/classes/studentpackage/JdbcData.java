package  studentpackage;
import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.util.*;
import java.sql.*;

public class JdbcData {  
    JdbcConnection jdbcobj = new JdbcConnection();
    Connection conn = null;

    ArrayList<Student> std = new ArrayList<Student>();
    public ArrayList<Student> getData(){
    try{
        conn = jdbcobj.getConnection();
        PreparedStatement stmt=conn.prepareStatement("select * from table_servlet");  
        ResultSet rs=stmt.executeQuery();  
        while (rs.next()) {
            String result,rcolor,m1c,m2c,m3c,m4c,m5c,printTotal ;
            String name = rs.getString(1).trim();
            int flag =0;
            int rollNo = Integer.parseInt(rs.getString(2));
            String  college = rs.getString(3).trim();
            String  dob = rs.getString(4).trim();
            String  department = rs.getString(5).trim();
            int m1 = rs.getInt(6);
            int m2 = rs.getInt(7);
            int m3 = rs.getInt(8);
            int m4 = rs.getInt(9);
            int m5 = rs.getInt(10);
            int total = rs.getInt(11);
            std.add(new Student(name,rollNo,college,dob,department,m1,m2,m3,m4,m5,total));
        } 
        rs.close();
		stmt.close();
		conn.close();   
    }
    catch(SQLException e){
        System.out.println(e); 
    }
    return(std);   
    }
}