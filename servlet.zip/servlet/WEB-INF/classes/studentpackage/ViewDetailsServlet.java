package  studentpackage;
import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.util.*;
import java.sql.*;

public class ViewDetailsServlet extends HttpServlet{
    JdbcData dataobj = new JdbcData();
    public void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException{
        ArrayList<Student> std = new ArrayList<Student>();
        PrintWriter out = response.getWriter();
        try{  
            response.setContentType("text/html");
            std = dataobj.getData();
            request.setAttribute("data", std);
            System.out.println(std);
            RequestDispatcher rd = request.getRequestDispatcher("viewdetails.jsp");
            rd.include(request, response);            
        }catch (Exception e)
        {
            out.print(e);
            e.printStackTrace();
        }
    }
}