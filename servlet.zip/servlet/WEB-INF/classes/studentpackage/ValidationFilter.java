package  studentpackage;
import java.io.*;  
import javax.servlet.*;  
import java.util.*;
import java.util.regex.*;
public class ValidationFilter implements Filter{  
  
    public void init(FilterConfig arg0) throws ServletException {}  
        
    public void doFilter(ServletRequest request, ServletResponse response,FilterChain chain) throws IOException, ServletException {  
        int flag =0;
        

        try{   
            response.setContentType("text/html");
            PrintWriter out = response.getWriter();
            String name       = request.getParameter("name");
            String rollNo     = request.getParameter("rollNo");
            String college    = request.getParameter("college");
            String department = request.getParameter("department");
            String m1         = request.getParameter("m1"); 
            String m2         = request.getParameter("m2");
            String m3         = request.getParameter("m3");
            String m4         = request.getParameter("m4");
            String m5         = request.getParameter("m5");
            String validationMessage="";
            if (name != null)
            {
                String regex = "^[A-Z][A-Za-z ]*$";             //Name
                Pattern namep = Pattern.compile(regex);
                Matcher namem = namep.matcher(name);
                if(!(namem.matches())){
                    flag = 1;
                    validationMessage="Enter valid name ! ! !"; 
                }
            }   
            if (rollNo != null && flag == 0) {
                String regex = "^[0-9]{5}$";                        //Roll NO
                Pattern rollp = Pattern.compile(regex);
                Matcher rollm = rollp.matcher(rollNo);
                if(!(rollm.matches())){
                    flag = 1;
                    validationMessage="! ! ! Enter valid Roll Number ! ! !"; 
                }
            }
            if (college != null && flag == 0) {
                String regex = "^[A-Za-z]*|[.]*|[/]* $";                //College
                Pattern collegep = Pattern.compile(regex);
                Matcher collegem = collegep.matcher(college);
                if(!(collegem.matches())){
                    flag = 1;
                    validationMessage="Enter valid College Name ! ! !"; 
                }
            }
            if (department != null && flag == 0) {
                String regex = "^[CSE]{3}|[ECE]{3}|[EEE]{3}|[IT]{2}|[ICE]{3}$";     //Department
                Pattern deptp = Pattern.compile(regex);
                Matcher deptm = deptp.matcher(department);
                if(!(deptm.matches())){
                    flag = 1;
                    validationMessage="Enter valid Department! ! !"; 
                }
            }
            if (m1 != null && flag == 0) {
                String regex = "^([0-9]|[1-9][0-9]|100)$";                //Mark 
                Pattern m1p = Pattern.compile(regex);
                Matcher m1m = m1p.matcher(m1);
                Pattern m2p = Pattern.compile(regex);
                Matcher m2m = m2p.matcher(m2);
                Pattern m3p = Pattern.compile(regex);
                Matcher m3m = m3p.matcher(m3);
                Pattern m4p = Pattern.compile(regex);
                Matcher m4m = m4p.matcher(m4);
                Pattern m5p = Pattern.compile(regex);       
                Matcher m5m = m5p.matcher(m5);
                if(!(m1m.matches()) ||!(m2m.matches()) ||!(m3m.matches()) ||!(m4m.matches()) ||!(m5m.matches())){
                    flag = 1;
                    validationMessage="Enter valid Mark ! ! !"; 
                }
            }
            if (flag == 0){
                chain.doFilter(request, response);    
            }
            else{
                response.getWriter().write(validationMessage);
            }
        }catch(Exception e){
            PrintWriter out=response.getWriter();  
            out.print(e);
            e.printStackTrace();
        }         
    }  
    public void destroy() {}  
  
}  