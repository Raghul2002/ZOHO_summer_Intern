package  studentpackage;
import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;

public class AdminServlet extends HttpServlet{

    public void doGet(HttpServletRequest request, HttpServletResponse response) {
        try{
            RequestDispatcher l= request.getRequestDispatcher("/WEB-INF/admin.jsp");
            l.forward(request, response);
        }catch(Exception e)
        {
            e.printStackTrace();
        }
    }
}   