package  studentpackage;
public class Student {
    String name;
	int rollNo;
	String college;
    String dob;
    String department;
	int m1;
	int m2;
	int m3;
	int m4;
	int m5;
	int total;
    // Parameterized Constructor to set Student
	public Student(String name,int rollNo,String college,String dob,String department,int m1,int m2,int m3,int m4,int m5,int total)
	{
		this.name = name;
		this.rollNo = rollNo;
		this.college =college;
        this.dob = dob;
        this.department= department;
		this.m1 = m1;
		this.m2 =m2;
		this.m3 =m3;
		this.m4=m4;
		this.m5=m5;
		this.total = total;
	}
    // Setter Methods to set table data to be
    // displayed
    public String getName() { return name; }
    public int getRollNo() { return rollNo; }
    public String getCollege() { return college; }
    public String getDob() { return dob; }
    public String getDepartment() { return department; }
    public int getM1() { return m1; }
    public int getM2() { return m2; }
    public int getM3() { return m3; }
    public int getM4() { return m4; }
    public int getM5() { return m5; }
    public int getTotal() { return total; }
}
