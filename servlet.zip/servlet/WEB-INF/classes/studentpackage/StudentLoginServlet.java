package  studentpackage;
import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.util.*;
import java.sql.*;

public class StudentLoginServlet extends HttpServlet{
    public void doGet(HttpServletRequest request,HttpServletResponse response){
        try{
            RequestDispatcher l= request.getRequestDispatcher("/student.jsp");
            l.forward(request, response);
        }catch(Exception e)
        {
            e.printStackTrace();
        }
    }
}