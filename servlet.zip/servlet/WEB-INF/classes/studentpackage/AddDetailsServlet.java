package  studentpackage;
import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.util.*;
import java.sql.*;

public class AddDetailsServlet extends HttpServlet{
    JdbcConnection jdbcobj = new JdbcConnection();
    public void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException{ 
        try{
            int total;
            response.setContentType("text/html");
            PrintWriter out = response.getWriter();
            Connection conn = jdbcobj.getConnection();
            String  name= request.getParameter("name");
            int  rollNo = Integer.parseInt(request.getParameter("rollNo"));
            String  college= request.getParameter("college");
            String  dob = request.getParameter("dob");  
            String  department= request.getParameter("department");         
            int  m1 = Integer.parseInt(request.getParameter("m1")); 
            int  m2 = Integer.parseInt(request.getParameter("m2"));
            int  m3 = Integer.parseInt(request.getParameter("m3"));
            int  m4 = Integer.parseInt(request.getParameter("m4"));
            int  m5 = Integer.parseInt(request.getParameter("m5"));
            total = m1+m2+m3+m4+m5;
            PreparedStatement stmt=conn.prepareStatement("insert into table_servlet (name,rollno,college,dob,department,m1,m2,m3,m4,m5,total) values (?,?,?,?,?,?,?,?,?,?,?)");  
            stmt.setString(1,name);
            stmt.setInt(2,rollNo);
            stmt.setString(3,college);
            stmt.setString(4,dob);  
            stmt.setString(5,department);
            stmt.setInt(6,m1);
            stmt.setInt(7,m2);
            stmt.setInt(8,m3);
            stmt.setInt(9,m4);
            stmt.setInt(10,m5);
            stmt.setInt(11,total);  
            stmt.executeUpdate();  
            stmt.close();
            conn.close();
            String validationMessage ="success";
            response.getWriter().write(validationMessage);
        }catch (Exception e)
        {   
            e.printStackTrace();   
        }
    }
    
}